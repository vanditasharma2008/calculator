var sum="";
function display(val)
{
	
	if(val=='+/-')
	{
	
			sum+='-';
    }
	else
	{
	sum+=val
	}
    
	document.getElementById("display").setAttribute("value",sum);
}
function evaluates(n)
{
	document.getElementById("display").setAttribute("value",eval(sum));
}
function clearscreen(m)
{
	sum=""
	document.getElementById("display").setAttribute("value","");
}